#include <opencv2/opencv.hpp>
#include <vector>
using namespace std;
using namespace cv;
int down(int k) 
{
    // 读取原始图像
    Mat img = imread("../wuda.jpg");
    Mat down(img.rows / k, img.cols / k, img.type());//创建一个缩小后的图像
    for (int y = 0; y < down.rows; y++) 
    {
        for (int x = 0; x < down.cols; x++) 
            {
                down.at<Vec3b>(y, x) =img.at<Vec3b>(y * k, x * k);//用at将三通道img每个像素值乘以2复制到up
            }
    }
    imshow("缩小图", down);
    waitKey(0);
    destroyAllWindows();
    return 0;
}

int up( int k) 
{
    Mat img = imread("../wuda.jpg");
    Mat up(img.rows * k, img.cols * k, img.type());
    // 使用at方法执行向上采样
    for (int y = 0; y < up.rows; y++) 
    {
        for (int x = 0; x < up.cols; x++) 
        {
            up.at<Vec3b>(y, x) = img.at<Vec3b>(y / k, x / k);//将三通道img每个像素值除以2复制到up
        }
    }
    // 显示向上采样后的图像
    imshow("放大图", up);
    waitKey(0);
    destroyAllWindows();

    return 0;
}
int main()
{
    int flag;
    int k;
    cout << "请选择放大/缩小" << endl;
    cout << "1:放大" << "\n" << "2:缩小" << endl;
    cin >> flag;
    cout << "请选择缩放系数" << endl;
    cin >> k;
    if (flag == 1)
        up(2);
    else if (flag == 2)
        down(2);
    return 0;
}
