#include <opencv2/highgui/highgui.hpp>    
#include <opencv2/imgproc/imgproc.hpp>
#include<iostream>
using namespace cv;
using namespace std;
Mat gammaTrans(Mat& m_img, double gamma, int c)
{

	Mat m_imgGamma(m_img.size(), CV_32FC3);
	for (int i = 0; i < m_img.rows; i++)
		for (int j = 0; j < m_img.cols; j++)
		{
			m_imgGamma.at<Vec3f>(i, j)[0] = c * pow(m_img.at<Vec3b>(i, j)[0], gamma);  //使用动态寻址方式
			m_imgGamma.at<Vec3f>(i, j)[1] = c * pow(m_img.at<Vec3b>(i, j)[1], gamma);
			m_imgGamma.at<Vec3f>(i, j)[2] = c * pow(m_img.at<Vec3b>(i, j)[2], gamma);
		}
	normalize(m_imgGamma, m_imgGamma, 0, 255, NORM_MINMAX);
	convertScaleAbs(m_imgGamma, m_img);  //将CV_32F的图像转成CV_8U的
	return m_img;
}

int main()
{
	Mat img, gamma;
	img = imread("../o.jpg", 1);
	if (img.empty())
	{
		cout << "请确认图像文件名称是否正确" << endl;
		return -1;
	}
	imshow("原图", img);
	gamma = gammaTrans(img, 1/2.2, 1);
	imshow("Gamma变换效果图", gamma);
	waitKey(0);
	return 0;
}

