#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>

using namespace std;
using namespace cv;

Mat ColorFindContours(Mat srcImage,
	int iLowH, int iHighH,
	int iLowS, int iHighS,
	int iLowV, int iHighV)
{
	Mat bufImg;
	Mat imgHSV;
	//转为HSV
	cvtColor(srcImage, imgHSV, COLOR_BGR2HSV);
	inRange(imgHSV, Scalar(iLowH, iLowS, iLowV), Scalar(iHighH, iHighS, iHighV), bufImg);
	return bufImg;
}

Mat ColorFindContours1(Mat srcImage)
{
	Mat des1 = ColorFindContours(srcImage,
		200 / 2, 248 / 2,                // 色调最小值~最大值
		int(255 * 0.75), int(255),   // 饱和度最小值~最大值
		(255 * 0.50), (255 * 0.70));  // 亮度最小值~最大值

	return des1;
}
Mat car(Mat img)
{
	Mat des2 = ColorFindContours1(img);
	Mat binary;
	Mat dst;
	GaussianBlur(des2, des2, Size(9, 9), 2, 2);//高斯滤波
	threshold(des2, binary, 170, 255, THRESH_BINARY | THRESH_OTSU);//二值化

	Mat kernel = getStructuringElement(MORPH_RECT, Size(22, 22), Point(-1, -1));//膨胀操作参数大小设为22*22
	dilate(binary, dst, kernel);

	vector<vector<Point>> contours;
	vector<Vec4i> hierarchy;
	findContours(dst, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point());

	Point2f ps[4];
	for (int i = 0; i < contours.size(); ++i)
	{  //遍历所有轮廓
		double areal = contourArea(contours[i]);
		if (areal > 500)
		{
			Rect rect = boundingRect(contours[i]);  //获取轮廓的外接矩形
			rectangle(img, rect, Scalar(0, 255, 0), 5);  //绘制轮廓矩形
			//保存轮廓
			Mat selectedRegion = img(rect);
			imwrite("jieguo.jpg", selectedRegion);
		}
	}
	return img;
}
int main()
{
    Mat img = imread("../5.jpg");
    if (img.empty())
    {
        cout << "请确认图像文件名称是否正确" << endl;
        return -1;
    }
    Mat rotation1,img_warp1,rotation2, img_warp2;
    Size dst_size(img.rows, img.cols); //设置输出图像的尺寸
    //根据定义的三个点进行仿射变换
    Point2f src_points[3];
    Point2f dst_points[3];
    src_points[0] = Point2f(324, 419); //原始图像中的三个点
    src_points[1] = Point2f(496, 267);
    src_points[2] = Point2f(496, 326);
    //放射变换后图像中的三个点
    dst_points[0] = Point2f((float)(img.rows) * 0.4, (float)(img.cols) * 0.20);
    dst_points[1] = Point2f((float)(img.rows) * 0.8, (float)(img.cols) * 0.20);
    dst_points[2] = Point2f((float)(img.rows) * 0.8, (float)(img.cols) * 0.4);
    rotation1 = getAffineTransform(src_points, dst_points); //根据对应点求取仿射变换矩阵
    warpAffine(img, img_warp1, rotation1, dst_size); //进行仿射变换

	/*透视变换*/
    Point2f src_points1[4];
    Point2f dst_points1[4];
    //变换前图片四个角点坐标
    src_points1[0] = Point2f(319, 119);
    src_points1[1] = Point2f(348, 267);
    src_points1[2] = Point2f(636, 121);
    src_points1[3] = Point2f(637, 237);
    //期望变换后图片四个角点的坐标
    dst_points1[0] = Point2f(320, 120);
    dst_points1[1] = Point2f(320, 260);
    dst_points1[2] = Point2f(650, 120);
    dst_points1[3] = Point2f(655, 243);
    rotation2 = getPerspectiveTransform(src_points1, dst_points1); //计算透视变换矩阵
    warpPerspective(img_warp1, img_warp2, rotation2, dst_size); //透视变换投影;

    imshow("img_warp2", img_warp2);
	Mat result = car(img_warp2);
	namedWindow("result", 0);
	imshow("result", result);//显示结果
	imwrite("result.jpg", result);
	waitKey(0);
    return 0;

}
